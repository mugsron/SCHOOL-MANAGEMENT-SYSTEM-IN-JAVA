package com.smartcampus.repository;

import com.smartcampus.model.Attendance;
import com.smartcampus.model.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    List<Attendance> findByEnrollment(Enrollment enrollment);
    List<Attendance> findByEnrollmentIn(List<Enrollment> enrollments);
}
