package com.smartcampus.repository;

import com.smartcampus.model.CourseAssignment;
import com.smartcampus.model.Lecturer;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CourseAssignmentRepository extends JpaRepository<CourseAssignment, Long> {
    List<CourseAssignment> findByLecturer(Lecturer lecturer);
}
