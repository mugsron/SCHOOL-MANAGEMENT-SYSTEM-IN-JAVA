package com.smartcampus.repository;

import com.smartcampus.model.Enrollment;
import com.smartcampus.model.Mark;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface MarkRepository extends JpaRepository<Mark, Long> {
    Optional<Mark> findByEnrollment(Enrollment enrollment);
}
