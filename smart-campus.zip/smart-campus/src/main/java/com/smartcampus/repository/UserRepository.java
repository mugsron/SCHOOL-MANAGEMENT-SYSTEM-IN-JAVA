package com.smartcampus.repository;

import com.smartcampus.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

// Extending JpaRepository gives us save(), findAll(), findById(), delete()
// etc. for free - no SQL written by hand. findByUsername is a "derived
// query": Spring reads the method name and builds the SQL automatically.
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
}
