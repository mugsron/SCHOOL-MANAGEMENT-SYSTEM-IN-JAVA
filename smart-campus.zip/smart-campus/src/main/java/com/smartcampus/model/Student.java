package com.smartcampus.model;

import jakarta.persistence.*;

@Entity
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String regNo; // registration number, e.g. "2024/CS/001"

    @Column(nullable = false)
    private String fullName;

    private int yearOfStudy = 1;

    @ManyToOne
    @JoinColumn(name = "program_id")
    private Program program;

    @OneToOne
    @JoinColumn(name = "user_id", unique = true)
    private User user;

    public Student() {}

    public Student(String regNo, String fullName, int yearOfStudy, Program program, User user) {
        this.regNo = regNo;
        this.fullName = fullName;
        this.yearOfStudy = yearOfStudy;
        this.program = program;
        this.user = user;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getRegNo() { return regNo; }
    public void setRegNo(String regNo) { this.regNo = regNo; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public int getYearOfStudy() { return yearOfStudy; }
    public void setYearOfStudy(int yearOfStudy) { this.yearOfStudy = yearOfStudy; }
    public Program getProgram() { return program; }
    public void setProgram(Program program) { this.program = program; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
}
