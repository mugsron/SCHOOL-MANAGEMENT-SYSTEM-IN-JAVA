package com.smartcampus.model;

import jakarta.persistence.*;

@Entity
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String code; // e.g. "CS201"

    @Column(nullable = false)
    private String name; // e.g. "Data Structures and Algorithms"

    private int creditUnits = 3;

    @ManyToOne
    @JoinColumn(name = "program_id")
    private Program program;

    public Course() {}

    public Course(String code, String name, int creditUnits, Program program) {
        this.code = code;
        this.name = name;
        this.creditUnits = creditUnits;
        this.program = program;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getCreditUnits() { return creditUnits; }
    public void setCreditUnits(int creditUnits) { this.creditUnits = creditUnits; }
    public Program getProgram() { return program; }
    public void setProgram(Program program) { this.program = program; }
}
