package com.smartcampus.model;

import jakarta.persistence.*;

@Entity
public class Lecturer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String fullName;

    @Column(nullable = false, unique = true)
    private String staffNo;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

    // Link to the login account. One lecturer = one user.
    @OneToOne
    @JoinColumn(name = "user_id", unique = true)
    private User user;

    public Lecturer() {}

    public Lecturer(String fullName, String staffNo, Department department, User user) {
        this.fullName = fullName;
        this.staffNo = staffNo;
        this.department = department;
        this.user = user;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getStaffNo() { return staffNo; }
    public void setStaffNo(String staffNo) { this.staffNo = staffNo; }
    public Department getDepartment() { return department; }
    public void setDepartment(Department department) { this.department = department; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
}
