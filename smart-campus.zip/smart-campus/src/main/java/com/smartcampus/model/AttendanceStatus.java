package com.smartcampus.model;

public enum AttendanceStatus {
    PRESENT,
    ABSENT,
    LATE
}
