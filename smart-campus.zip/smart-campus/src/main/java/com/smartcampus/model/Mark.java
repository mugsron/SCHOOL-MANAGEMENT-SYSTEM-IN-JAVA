package com.smartcampus.model;

import jakarta.persistence.*;

// One Mark row per Enrollment. total and grade are recalculated
// automatically (see GradeUtil) whenever a lecturer saves marks -
// this satisfies objective #8 "automatically calculate student grades".
@Entity
public class Mark {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "enrollment_id", unique = true)
    private Enrollment enrollment;

    private double courseworkMark; // out of 40
    private double examMark;       // out of 60
    private double total;          // out of 100, computed
    private String grade;          // A/B/C/D/F, computed
    private double gradePoint;     // 4.0/3.0/2.0/1.0/0.0, computed

    public Mark() {}

    public Mark(Enrollment enrollment, double courseworkMark, double examMark) {
        this.enrollment = enrollment;
        this.courseworkMark = courseworkMark;
        this.examMark = examMark;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Enrollment getEnrollment() { return enrollment; }
    public void setEnrollment(Enrollment enrollment) { this.enrollment = enrollment; }
    public double getCourseworkMark() { return courseworkMark; }
    public void setCourseworkMark(double courseworkMark) { this.courseworkMark = courseworkMark; }
    public double getExamMark() { return examMark; }
    public void setExamMark(double examMark) { this.examMark = examMark; }
    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }
    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }
    public double getGradePoint() { return gradePoint; }
    public void setGradePoint(double gradePoint) { this.gradePoint = gradePoint; }
}
