package com.smartcampus.model;

// The three user types from the brief. Spring Security checks this
// to decide which pages/URLs a logged-in user is allowed to reach.
public enum Role {
    ADMIN,
    LECTURER,
    STUDENT
}
