package com.smartcampus.model;

import jakarta.persistence.*;

// Represents "this Student is registered for this Course this term".
// Attendance and Marks both hang off an Enrollment, not directly off
// Student+Course, because attendance/marks are always specific to one
// registration period.
@Entity
public class Enrollment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;

    @ManyToOne
    @JoinColumn(name = "course_id")
    private Course course;

    private String academicYear;
    private String semester;

    public Enrollment() {}

    public Enrollment(Student student, Course course, String academicYear, String semester) {
        this.student = student;
        this.course = course;
        this.academicYear = academicYear;
        this.semester = semester;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }
    public String getAcademicYear() { return academicYear; }
    public void setAcademicYear(String academicYear) { this.academicYear = academicYear; }
    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }
}
