package com.smartcampus.model;

import jakarta.persistence.*;

// Links a Lecturer to a Course for a specific academic year/semester.
// This is a "join table with extra data" - a many-to-many between
// Lecturer and Course, modeled explicitly because we need to record
// WHEN the assignment applies.
@Entity
public class CourseAssignment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "lecturer_id")
    private Lecturer lecturer;

    @ManyToOne
    @JoinColumn(name = "course_id")
    private Course course;

    private String academicYear; // e.g. "2025/2026"
    private String semester;     // e.g. "Semester 1"

    public CourseAssignment() {}

    public CourseAssignment(Lecturer lecturer, Course course, String academicYear, String semester) {
        this.lecturer = lecturer;
        this.course = course;
        this.academicYear = academicYear;
        this.semester = semester;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Lecturer getLecturer() { return lecturer; }
    public void setLecturer(Lecturer lecturer) { this.lecturer = lecturer; }
    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }
    public String getAcademicYear() { return academicYear; }
    public void setAcademicYear(String academicYear) { this.academicYear = academicYear; }
    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }
}
