package com.smartcampus.controller;

import com.smartcampus.model.*;
import com.smartcampus.repository.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

// Every method here is only reachable by ROLE_ADMIN - enforced centrally
// in SecurityConfig ("/admin/**" -> hasRole("ADMIN")), so we don't need
// to re-check the role in each method.
@Controller
@RequestMapping("/admin")
public class AdminController {

    private final DepartmentRepository departmentRepo;
    private final ProgramRepository programRepo;
    private final CourseRepository courseRepo;
    private final LecturerRepository lecturerRepo;
    private final StudentRepository studentRepo;
    private final UserRepository userRepo;
    private final CourseAssignmentRepository assignmentRepo;

    public AdminController(DepartmentRepository departmentRepo, ProgramRepository programRepo,
                            CourseRepository courseRepo, LecturerRepository lecturerRepo,
                            StudentRepository studentRepo, UserRepository userRepo,
                            CourseAssignmentRepository assignmentRepo) {
        this.departmentRepo = departmentRepo;
        this.programRepo = programRepo;
        this.courseRepo = courseRepo;
        this.lecturerRepo = lecturerRepo;
        this.studentRepo = studentRepo;
        this.userRepo = userRepo;
        this.assignmentRepo = assignmentRepo;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("studentCount", studentRepo.count());
        model.addAttribute("lecturerCount", lecturerRepo.count());
        model.addAttribute("courseCount", courseRepo.count());
        model.addAttribute("departmentCount", departmentRepo.count());
        return "admin/dashboard";
    }

    // ---------- Departments ----------
    @GetMapping("/departments")
    public String departments(Model model) {
        model.addAttribute("departments", departmentRepo.findAll());
        model.addAttribute("department", new Department());
        return "admin/departments";
    }

    @PostMapping("/departments")
    public String addDepartment(@ModelAttribute Department department) {
        departmentRepo.save(department);
        return "redirect:/admin/departments";
    }

    @PostMapping("/departments/{id}/delete")
    public String deleteDepartment(@PathVariable Long id) {
        departmentRepo.deleteById(id);
        return "redirect:/admin/departments";
    }

    // ---------- Programs ----------
    @GetMapping("/programs")
    public String programs(Model model) {
        model.addAttribute("programs", programRepo.findAll());
        model.addAttribute("departments", departmentRepo.findAll());
        return "admin/programs";
    }

    @PostMapping("/programs")
    public String addProgram(@RequestParam String name, @RequestParam Long departmentId) {
        Department dept = departmentRepo.findById(departmentId).orElseThrow();
        programRepo.save(new Program(name, dept));
        return "redirect:/admin/programs";
    }

    @PostMapping("/programs/{id}/delete")
    public String deleteProgram(@PathVariable Long id) {
        programRepo.deleteById(id);
        return "redirect:/admin/programs";
    }

    // ---------- Courses ----------
    @GetMapping("/courses")
    public String courses(Model model) {
        model.addAttribute("courses", courseRepo.findAll());
        model.addAttribute("programs", programRepo.findAll());
        return "admin/courses";
    }

    @PostMapping("/courses")
    public String addCourse(@RequestParam String code, @RequestParam String name,
                             @RequestParam int creditUnits, @RequestParam Long programId) {
        Program program = programRepo.findById(programId).orElseThrow();
        courseRepo.save(new Course(code, name, creditUnits, program));
        return "redirect:/admin/courses";
    }

    @PostMapping("/courses/{id}/delete")
    public String deleteCourse(@PathVariable Long id) {
        courseRepo.deleteById(id);
        return "redirect:/admin/courses";
    }

    // ---------- Lecturers ----------
    @GetMapping("/lecturers")
    public String lecturers(Model model) {
        model.addAttribute("lecturers", lecturerRepo.findAll());
        model.addAttribute("departments", departmentRepo.findAll());
        return "admin/lecturers";
    }

    // Creating a lecturer creates BOTH a login (User) and a profile
    // (Lecturer) in one form submission - this is a common pattern
    // worth pointing out in your viva: two related tables, one form.
    @PostMapping("/lecturers")
    public String addLecturer(@RequestParam String fullName, @RequestParam String staffNo,
                               @RequestParam Long departmentId, @RequestParam String username,
                               @RequestParam String password) {
        Department dept = departmentRepo.findById(departmentId).orElseThrow();
        User user = userRepo.save(new User(username, "{noop}" + password, Role.LECTURER));
        lecturerRepo.save(new Lecturer(fullName, staffNo, dept, user));
        return "redirect:/admin/lecturers";
    }

    @PostMapping("/lecturers/{id}/delete")
    public String deleteLecturer(@PathVariable Long id) {
        Lecturer lecturer = lecturerRepo.findById(id).orElseThrow();
        lecturerRepo.deleteById(id);
        userRepo.deleteById(lecturer.getUser().getId());
        return "redirect:/admin/lecturers";
    }

    // ---------- Students ----------
    @GetMapping("/students")
    public String students(Model model) {
        model.addAttribute("students", studentRepo.findAll());
        model.addAttribute("programs", programRepo.findAll());
        return "admin/students";
    }

    @PostMapping("/students")
    public String addStudent(@RequestParam String fullName, @RequestParam String regNo,
                              @RequestParam int yearOfStudy, @RequestParam Long programId,
                              @RequestParam String username, @RequestParam String password) {
        Program program = programRepo.findById(programId).orElseThrow();
        User user = userRepo.save(new User(username, "{noop}" + password, Role.STUDENT));
        studentRepo.save(new Student(regNo, fullName, yearOfStudy, program, user));
        return "redirect:/admin/students";
    }

    @PostMapping("/students/{id}/delete")
    public String deleteStudent(@PathVariable Long id) {
        Student student = studentRepo.findById(id).orElseThrow();
        studentRepo.deleteById(id);
        userRepo.deleteById(student.getUser().getId());
        return "redirect:/admin/students";
    }

    // ---------- Course Assignments (lecturer teaches course) ----------
    @GetMapping("/assignments")
    public String assignments(Model model) {
        model.addAttribute("assignments", assignmentRepo.findAll());
        model.addAttribute("lecturers", lecturerRepo.findAll());
        model.addAttribute("courses", courseRepo.findAll());
        return "admin/assignments";
    }

    @PostMapping("/assignments")
    public String addAssignment(@RequestParam Long lecturerId, @RequestParam Long courseId,
                                 @RequestParam String academicYear, @RequestParam String semester) {
        Lecturer lecturer = lecturerRepo.findById(lecturerId).orElseThrow();
        Course course = courseRepo.findById(courseId).orElseThrow();
        assignmentRepo.save(new CourseAssignment(lecturer, course, academicYear, semester));
        return "redirect:/admin/assignments";
    }

    @PostMapping("/assignments/{id}/delete")
    public String deleteAssignment(@PathVariable Long id) {
        assignmentRepo.deleteById(id);
        return "redirect:/admin/assignments";
    }
}
