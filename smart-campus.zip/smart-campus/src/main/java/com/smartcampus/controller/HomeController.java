package com.smartcampus.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    // After a successful login, Spring Security sends everyone here.
    // We look at their role and forward them to the right dashboard -
    // this is what gives each of the 3 user types its own "home".
    @GetMapping("/")
    public String home(Authentication authentication) {
        for (GrantedAuthority authority : authentication.getAuthorities()) {
            String role = authority.getAuthority();
            if (role.equals("ROLE_ADMIN")) return "redirect:/admin/dashboard";
            if (role.equals("ROLE_LECTURER")) return "redirect:/lecturer/dashboard";
            if (role.equals("ROLE_STUDENT")) return "redirect:/student/dashboard";
        }
        return "redirect:/login";
    }
}
