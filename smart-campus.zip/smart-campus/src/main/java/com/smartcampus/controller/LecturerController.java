package com.smartcampus.controller;

import com.smartcampus.model.*;
import com.smartcampus.repository.*;
import com.smartcampus.util.GradeUtil;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/lecturer")
public class LecturerController {

    private final LecturerRepository lecturerRepo;
    private final UserRepository userRepo;
    private final CourseAssignmentRepository assignmentRepo;
    private final CourseRepository courseRepo;
    private final EnrollmentRepository enrollmentRepo;
    private final AttendanceRepository attendanceRepo;
    private final MarkRepository markRepo;

    public LecturerController(LecturerRepository lecturerRepo, UserRepository userRepo,
                               CourseAssignmentRepository assignmentRepo, CourseRepository courseRepo,
                               EnrollmentRepository enrollmentRepo, AttendanceRepository attendanceRepo,
                               MarkRepository markRepo) {
        this.lecturerRepo = lecturerRepo;
        this.userRepo = userRepo;
        this.assignmentRepo = assignmentRepo;
        this.courseRepo = courseRepo;
        this.enrollmentRepo = enrollmentRepo;
        this.attendanceRepo = attendanceRepo;
        this.markRepo = markRepo;
    }

    // Every method below needs to know "which Lecturer is currently
    // logged in?". We get the username from Spring Security's
    // Authentication object, look up the User, then the linked Lecturer.
    private Lecturer currentLecturer(Authentication auth) {
        User user = userRepo.findByUsername(auth.getName()).orElseThrow();
        return lecturerRepo.findByUser(user).orElseThrow();
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model, Authentication auth) {
        Lecturer lecturer = currentLecturer(auth);
        model.addAttribute("lecturer", lecturer);
        model.addAttribute("assignments", assignmentRepo.findByLecturer(lecturer));
        return "lecturer/dashboard";
    }

    @GetMapping("/attendance")
    public String attendanceForm(@RequestParam Long courseId, Model model, Authentication auth) {
        Course course = courseRepo.findById(courseId).orElseThrow();
        List<Enrollment> enrollments = enrollmentRepo.findByCourse(course);
        model.addAttribute("course", course);
        model.addAttribute("enrollments", enrollments);
        model.addAttribute("today", LocalDate.now());
        return "lecturer/attendance";
    }

    // One form submission records attendance for every student enrolled
    // in the course on the given date. enrollmentIds/statuses are two
    // parallel arrays coming from the template's checkboxes/selects.
    @PostMapping("/attendance")
    public String saveAttendance(@RequestParam Long courseId, @RequestParam String date,
                                  @RequestParam List<Long> enrollmentIds,
                                  @RequestParam List<String> statuses) {
        LocalDate attendanceDate = LocalDate.parse(date);
        for (int i = 0; i < enrollmentIds.size(); i++) {
            Enrollment enrollment = enrollmentRepo.findById(enrollmentIds.get(i)).orElseThrow();
            AttendanceStatus status = AttendanceStatus.valueOf(statuses.get(i));
            attendanceRepo.save(new Attendance(enrollment, attendanceDate, status));
        }
        return "redirect:/lecturer/attendance?courseId=" + courseId;
    }

    @GetMapping("/marks")
    public String marksForm(@RequestParam Long courseId, Model model) {
        Course course = courseRepo.findById(courseId).orElseThrow();
        List<Enrollment> enrollments = enrollmentRepo.findByCourse(course);
        model.addAttribute("course", course);
        model.addAttribute("enrollments", enrollments);
        model.addAttribute("markRepo", markRepo); // used in template to pre-fill existing marks
        return "lecturer/marks";
    }

    // Grade is calculated here on the server (objective #8), never
    // trusted from the browser - the student can't fake their own grade
    // by tampering with form fields.
    @PostMapping("/marks")
    public String saveMarks(@RequestParam Long courseId, @RequestParam List<Long> enrollmentIds,
                             @RequestParam List<Double> courseworkMarks,
                             @RequestParam List<Double> examMarks) {
        for (int i = 0; i < enrollmentIds.size(); i++) {
            Enrollment enrollment = enrollmentRepo.findById(enrollmentIds.get(i)).orElseThrow();
            Mark mark = markRepo.findByEnrollment(enrollment).orElse(new Mark());
            mark.setEnrollment(enrollment);
            mark.setCourseworkMark(courseworkMarks.get(i));
            mark.setExamMark(examMarks.get(i));
            GradeUtil.applyGrade(mark);
            markRepo.save(mark);
        }
        return "redirect:/lecturer/marks?courseId=" + courseId;
    }
}
