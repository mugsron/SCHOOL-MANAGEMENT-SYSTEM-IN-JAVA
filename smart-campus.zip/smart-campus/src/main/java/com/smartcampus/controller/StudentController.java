package com.smartcampus.controller;

import com.smartcampus.model.*;
import com.smartcampus.repository.*;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/student")
public class StudentController {

    private final StudentRepository studentRepo;
    private final UserRepository userRepo;
    private final CourseRepository courseRepo;
    private final EnrollmentRepository enrollmentRepo;
    private final AttendanceRepository attendanceRepo;
    private final MarkRepository markRepo;

    public StudentController(StudentRepository studentRepo, UserRepository userRepo,
                              CourseRepository courseRepo, EnrollmentRepository enrollmentRepo,
                              AttendanceRepository attendanceRepo, MarkRepository markRepo) {
        this.studentRepo = studentRepo;
        this.userRepo = userRepo;
        this.courseRepo = courseRepo;
        this.enrollmentRepo = enrollmentRepo;
        this.attendanceRepo = attendanceRepo;
        this.markRepo = markRepo;
    }

    private Student currentStudent(Authentication auth) {
        User user = userRepo.findByUsername(auth.getName()).orElseThrow();
        return studentRepo.findByUser(user).orElseThrow();
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model, Authentication auth) {
        model.addAttribute("student", currentStudent(auth));
        return "student/dashboard";
    }

    @GetMapping("/courses")
    public String courses(Model model, Authentication auth) {
        Student student = currentStudent(auth);
        List<Enrollment> myEnrollments = enrollmentRepo.findByStudent(student);
        // Only show courses belonging to the student's own program, and
        // that they haven't already registered for.
        List<Course> available = courseRepo.findAll().stream()
                .filter(c -> c.getProgram().getId().equals(student.getProgram().getId()))
                .filter(c -> !enrollmentRepo.existsByStudentAndCourse(student, c))
                .toList();
        model.addAttribute("available", available);
        model.addAttribute("enrollments", myEnrollments);
        return "student/courses";
    }

    @PostMapping("/courses/register")
    public String register(@RequestParam Long courseId, @RequestParam String academicYear,
                            @RequestParam String semester, Authentication auth) {
        Student student = currentStudent(auth);
        Course course = courseRepo.findById(courseId).orElseThrow();
        if (!enrollmentRepo.existsByStudentAndCourse(student, course)) {
            enrollmentRepo.save(new Enrollment(student, course, academicYear, semester));
        }
        return "redirect:/student/courses";
    }

    @GetMapping("/attendance")
    public String attendance(Model model, Authentication auth) {
        Student student = currentStudent(auth);
        List<Enrollment> enrollments = enrollmentRepo.findByStudent(student);
        model.addAttribute("attendanceRecords", attendanceRepo.findByEnrollmentIn(enrollments));
        return "student/attendance";
    }

    // Shared by /results and /transcript - a transcript is just a formal,
    // printable view of the same underlying data, so we compute it once.
    private void loadResultsData(Model model, Authentication auth) {
        Student student = currentStudent(auth);
        List<Enrollment> enrollments = enrollmentRepo.findByStudent(student);

        // GPA = sum(gradePoint * creditUnits) / sum(creditUnits) across
        // every course the student has a recorded mark for - the
        // standard weighted-average GPA formula (objective: "view GPA").
        double totalPoints = 0;
        double totalCredits = 0;
        for (Enrollment e : enrollments) {
            var markOpt = markRepo.findByEnrollment(e);
            if (markOpt.isPresent()) {
                Mark m = markOpt.get();
                int credits = e.getCourse().getCreditUnits();
                totalPoints += m.getGradePoint() * credits;
                totalCredits += credits;
            }
        }
        double gpa = totalCredits > 0 ? totalPoints / totalCredits : 0.0;

        model.addAttribute("student", student);
        model.addAttribute("enrollments", enrollments);
        model.addAttribute("markRepo", markRepo);
        model.addAttribute("gpa", gpa);
    }

    @GetMapping("/results")
    public String results(Model model, Authentication auth) {
        loadResultsData(model, auth);
        return "student/results";
    }

    @GetMapping("/transcript")
    public String transcript(Model model, Authentication auth) {
        loadResultsData(model, auth);
        return "student/transcript";
    }
}
