package com.smartcampus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// This is the entry point. Spring Boot scans everything under
// com.smartcampus (controllers, services, repositories, security config)
// and wires it together automatically - that's what @SpringBootApplication does.
@SpringBootApplication
public class SmartCampusApplication {
    public static void main(String[] args) {
        SpringApplication.run(SmartCampusApplication.class, args);
    }
}
