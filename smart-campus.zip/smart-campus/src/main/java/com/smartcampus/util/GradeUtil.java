package com.smartcampus.util;

import com.smartcampus.model.Mark;

// Pure logic, no database/Spring dependency here on purpose - a "util"
// class is easy to unit test and easy to explain in a viva: given
// numbers in, grade out, no side effects.
public class GradeUtil {

    // Coursework is worth 40%, exam is worth 60% - a common university split.
    public static void applyGrade(Mark mark) {
        double total = mark.getCourseworkMark() + mark.getExamMark();
        mark.setTotal(total);

        if (total >= 70) {
            mark.setGrade("A");
            mark.setGradePoint(4.0);
        } else if (total >= 60) {
            mark.setGrade("B");
            mark.setGradePoint(3.0);
        } else if (total >= 50) {
            mark.setGrade("C");
            mark.setGradePoint(2.0);
        } else if (total >= 40) {
            mark.setGrade("D");
            mark.setGradePoint(1.0);
        } else {
            mark.setGrade("F");
            mark.setGradePoint(0.0);
        }
    }
}
