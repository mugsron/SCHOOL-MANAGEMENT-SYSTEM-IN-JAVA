-- Seed data so the app is ready to demo the moment it starts.
-- Passwords use the {noop} prefix, which tells Spring Security's
-- DelegatingPasswordEncoder "this is plain text, don't hash-check it".
-- That's fine for a coursework demo; a real system would store bcrypt
-- hashes instead (see README).

-- Login accounts: 1 admin, 2 lecturers, 3 students
INSERT INTO app_user (id, username, password, role, enabled) VALUES
  (1, 'admin', '{noop}admin123', 'ADMIN', true),
  (2, 'jmwangi', '{noop}lecturer123', 'LECTURER', true),
  (3, 'sokello', '{noop}lecturer123', 'LECTURER', true),
  (4, 'alice', '{noop}student123', 'STUDENT', true),
  (5, 'brian', '{noop}student123', 'STUDENT', true),
  (6, 'carol', '{noop}student123', 'STUDENT', true);

INSERT INTO department (id, code, name) VALUES
  (1, 'CS', 'Computer Science'),
  (2, 'BA', 'Business Administration');

INSERT INTO program (id, name, department_id) VALUES
  (1, 'Bachelor of Science in Computer Science', 1),
  (2, 'Bachelor of Business Administration', 2);

INSERT INTO course (id, code, name, credit_units, program_id) VALUES
  (1, 'CS101', 'Introduction to Programming', 3, 1),
  (2, 'CS201', 'Data Structures and Algorithms', 4, 1),
  (3, 'CS210', 'Database Systems', 3, 1),
  (4, 'BA101', 'Principles of Management', 3, 2);

INSERT INTO lecturer (id, full_name, staff_no, department_id, user_id) VALUES
  (1, 'Dr. James Mwangi', 'STF001', 1, 2),
  (2, 'Ms. Sarah Okello', 'STF002', 2, 3);

INSERT INTO student (id, reg_no, full_name, year_of_study, program_id, user_id) VALUES
  (1, '2024/CS/001', 'Alice Namu', 2, 1, 4),
  (2, '2024/CS/002', 'Brian Kato', 2, 1, 5),
  (3, '2024/BA/001', 'Carol Nakato', 1, 2, 6);

INSERT INTO course_assignment (id, lecturer_id, course_id, academic_year, semester) VALUES
  (1, 1, 1, '2025/2026', 'Semester 1'),
  (2, 1, 2, '2025/2026', 'Semester 1'),
  (3, 1, 3, '2025/2026', 'Semester 1'),
  (4, 2, 4, '2025/2026', 'Semester 1');

INSERT INTO enrollment (id, student_id, course_id, academic_year, semester) VALUES
  (1, 1, 1, '2025/2026', 'Semester 1'),
  (2, 1, 2, '2025/2026', 'Semester 1'),
  (3, 2, 1, '2025/2026', 'Semester 1'),
  (4, 3, 4, '2025/2026', 'Semester 1');

-- A couple of pre-entered marks so /student/results and the transcript
-- have something to show immediately during a demo.
INSERT INTO mark (id, enrollment_id, coursework_mark, exam_mark, total, grade, grade_point) VALUES
  (1, 1, 32, 55, 87, 'A', 4.0),
  (2, 3, 25, 40, 65, 'B', 3.0);
