# Smart Campus Student Management and Academic Information System

A Java Spring Boot web app covering student registration, courses, lecturer
assignment, attendance, coursework/exam marks, automatic grading, GPA,
transcripts, and role-based dashboards for Admin / Lecturer / Student.

## How to run it

You need **Java 17+** and **internet access** (Maven downloads the
Spring Boot libraries the first time you build).

1. Open the `smart-campus` folder in IntelliJ IDEA, Eclipse, or VS Code
   (with the Java Extension Pack).
2. Let it import as a Maven project (this happens automatically — it
   reads `pom.xml`).
3. Run `SmartCampusApplication.java` (right-click → Run), **or** from a
   terminal in the project folder:
   ```
   mvn spring-boot:run
   ```
4. Open **http://localhost:8080** in your browser. You'll land on the
   login page.

**Do this well before your deadline/demo**, not five minutes before —
the very first Maven build needs internet to download dependencies and
can take a few minutes.

## Demo login accounts (already seeded — no setup needed)

| Role     | Username  | Password       |
|----------|-----------|----------------|
| Admin    | admin     | admin123       |
| Lecturer | jmwangi   | lecturer123    |
| Student  | alice     | student123     |

The database is H2 (in-memory), so it resets to this seed data every
time you restart the app — handy for a clean, repeatable demo. You can
also add your own students/lecturers/courses live through the Admin UI.

To inspect the raw database tables, visit **http://localhost:8080/h2-console**
while the app is running (JDBC URL: `jdbc:h2:mem:smartcampus`, user `sa`,
no password).

## Switching to MySQL

The brief lists MySQL as the recommended database. To use it instead of H2:
1. Install MySQL and run `CREATE DATABASE smartcampus;`
2. In `src/main/resources/application.properties`, comment out the H2
   block and uncomment the MySQL block, filling in your password.
3. Restart the app — Hibernate will create the tables automatically.

## What's implemented (mapped to the brief's objectives)

- **Register and manage students** — Admin → Students
- **Manage departments and programs** — Admin → Departments / Programs
- **Manage courses** — Admin → Courses
- **Assign lecturers to courses** — Admin → Assignments
- **Register students for courses** — Student → Courses
- **Record attendance** — Lecturer → Attendance (per course, per date)
- **Record coursework + exam marks** — Lecturer → Marks
- **Automatic grade calculation** — `GradeUtil.applyGrade()`: total =
  coursework + exam, mapped to A/B/C/D/F and a 4.0-scale grade point
- **GPA** — weighted average of grade points by credit units, computed
  in `StudentController`
- **Transcript** — Student → Transcript (printable view)
- **Dashboards per role** — separate Admin / Lecturer / Student home pages
- **Role-based authentication** — Spring Security; `/admin/**`,
  `/lecturer/**`, `/student/**` are locked to their respective role
  (see `SecurityConfig.java`)

## Architecture, in one paragraph (for your viva)

This is a classic **layered MVC** app: **Model** (`model/` — JPA
entities mapped to database tables), **Repository** (`repository/` —
Spring Data JPA interfaces that generate SQL for you), **Controller**
(`controller/` — handles web requests, one per role), and **View**
(`templates/` — Thymeleaf HTML that Bootstrap styles). Authentication
and authorization are handled separately by **Spring Security**
(`security/`), which checks the logged-in user's role against the URL
before a request ever reaches a controller.

## If you get asked questions — quick answers

- **"Why three separate controllers?"** — Each role only needs its own
  set of actions, and Spring Security can lock down `/admin/**`,
  `/lecturer/**`, `/student/**` as whole URL prefixes, which is simpler
  and safer than checking roles inside a single giant controller.
- **"How does the system know who's logged in?"** — Spring Security
  puts the logged-in user in the request's `Authentication` object;
  each controller looks up the matching `Student`/`Lecturer` row from
  that.
- **"Why is grading calculated on the server, not in the form?"** — so
  a student can't fake their own grade by editing the page in their
  browser; the server is the only thing trusted with that logic.
- **"What's an Enrollment for, if you already have Student and
  Course?"** — it's the join between them ("this student is taking
  this course this semester"), and it's what Attendance and Marks are
  actually attached to.

## Known limitations (be upfront about these if asked)

- Passwords are stored as plain text prefixed with `{noop}` for demo
  speed. A production system would hash them with BCrypt
  (`passwordEncoder.encode(...)` — the `PasswordEncoder` bean is
  already wired up in `SecurityConfig`, it's just not used for the
  seed data or the admin "add user" forms yet).
- Deleting a Department/Program/Course that already has data linked to
  it (e.g. students, courses) will fail with a database constraint
  error, since cascading deletes aren't configured. Fine for a demo,
  worth mentioning as a "future improvement" if asked.
- Academic year/semester are free-text fields rather than their own
  managed entities, to keep the scope achievable in the time available.
